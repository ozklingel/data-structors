

import java.awt.Point;
import java.util.Arrays;

public class Ex1 {
	
	///q1
public static int maximumX(java.awt.Point[] vertices3) {
	int indmax=vertices3.length/2;//the bigest value index
	int f=0;//begin of the search
	int s=vertices3.length/2;//last of the search
	int mid =(f+s)/2;//we cheak this index
	while(f<s) {
		if (vertices3[mid].x<=vertices3[indmax].x)///if we dont find bigger chack half of it
			f=mid+1;
		if(vertices3[mid].x>=vertices3[indmax].x) {///if we find bigger do swap
			indmax=mid;
			f=mid+1;
			
		}
	mid=(f+s)/2;}
	
	 f=vertices3.length/2;//begin of the search
	 s=vertices3.length;//last of the search
	 mid =(f+s)/2;//we cheak this index
	while(f<s) {
		if (vertices3[mid].x<=vertices3[indmax].x)///if we dont find bigger chack half of it
			s=mid-1;
		if(vertices3[mid].x>=vertices3[indmax].x) {///if we find bigger do swap
			indmax=mid;
			s=mid-1;
	
}mid=(f+s)/2;
	
}return indmax;
}
//q1
public static int maximumY(java.awt.Point[] vertices3) {
	int indmax=vertices3.length/4;//the bigest value index
	int f=0; //begin of the search
	int s=vertices3.length/4;//last of the search
	int mid =(f+s)/2;//we cheak this index
	while(f<=s) {
		if (vertices3[mid].y<=vertices3[indmax].y)///if we dont find bigger chack half of it
			f=mid+1;
		if(vertices3[mid].y>=vertices3[indmax].y) {///if we find bigger do swap
			indmax=mid;
			f=mid+1;
			
		}
	mid=(f+s)/2;}
	
	 f=vertices3.length/2;//begin of the search
	 s=vertices3.length;//last of the search
	 mid =(f+s)/2;//we cheak this index
	while(f<=s) {
		if (vertices3[mid].y<=vertices3[indmax].y)///if we dont find bigger chack half of it
			s=mid-1;
		if(vertices3[mid].y>=vertices3[indmax].y) {///if we find bigger do swap
			indmax=mid;
			s=mid-1;
	
}mid=(f+s)/2;//half index chacking
	
}return indmax;
}




}
