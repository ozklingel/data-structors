

import java.util.Queue;
import java.util.Stack;

public class Ex2 {
///q1

public static int maxsum(Stack<Integer> s) {

Stack<Integer> temp=new Stack<Integer>();
int sumax = 0;
while (!s.isEmpty()) {
	int x=(int) s.pop();
	if(temp.isEmpty())
		break;
	int y=(int) s.pop();
	if(x+y>sumax)//change max if its bigger
		sumax=x+y;
	
	temp.push(x);
	s.push(y);
}
while(!temp.isEmpty())
	s.push(temp.pop());
return sumax;

}

///q1.2
public static int topbig(Stack<Integer> s1,
Stack<Integer> s2) {

Stack<Integer> temp=new Stack<Integer>();


int x=maxsum(s2);//max in s2
int ans=x;//the answer

while(!s1.isEmpty()) 
	temp.push(s1.pop());///contras the stack
while(!temp.isEmpty()) {
	int y=temp.pop();///first alement
	if (temp.isEmpty())//if empty get out
		break;
	else {
	int z=temp.pop();	///seceond element	
	if(y+z>x)///if bigger change
		ans=y+z;
	s1.push(y);
	temp.push(z);
}}
if(ans==x)
	return(0);
return ans;
			

}

///q2
public static void func2(Queue<Integer> q,Stack<Integer> s) {

Stack<Integer> t=new Stack<Integer>();
while(!s.isEmpty())    ////enter the stack to another stack in different seder
	t.push((Integer) s.pop());
while(!t.isEmpty() && !q.isEmpty()) {///who is bigger is the first
	int y=(int) q.peek();
	int z=(int) t.peek();	
	if(y>z)
		s.push(q.remove());
	s.push(t.pop());
}

if(q.isEmpty()) {
	while(!t.isEmpty())
		s.push(t.pop());
}
while(!q.isEmpty())
	s.push(q.remove());

while(!s.isEmpty())
	q.add(s.pop());

while(!q.isEmpty())
	s.push(q.remove());
}

}
